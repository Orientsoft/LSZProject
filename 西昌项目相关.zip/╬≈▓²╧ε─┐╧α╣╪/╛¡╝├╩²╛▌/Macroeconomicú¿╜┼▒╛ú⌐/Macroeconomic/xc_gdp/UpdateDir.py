import os
import time

old_mtime = os.path.getmtime('/home/samba/samba/')

def checkmtime():
	while True:
		global old_mtime
		now_mtime = os.path.getmtime('/home/samba/samba/')
		if old_mtime == now_mtime:
			pass
		else:
			os.system('cp /home/samba/samba/*.xls /opt/voyager/apps/Macroeconomic/xc_gdp/ -f')
			os.system('/bin/bash /opt/voyager/apps/Macroeconomic/xc_gdp/start-gdp.sh')
			print('Updated')
			old_mtime = now_mtime
		time.sleep(10)

checkmtime()

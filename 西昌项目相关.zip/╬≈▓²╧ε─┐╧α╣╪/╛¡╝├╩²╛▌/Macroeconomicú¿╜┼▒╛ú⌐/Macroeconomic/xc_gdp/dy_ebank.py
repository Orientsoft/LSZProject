import time
import subprocess
while True:
	ps = subprocess.Popen('ps -ef|grep readtime.py|grep -v grep',stdin=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
	lines = ps.stdout.readlines()
	if len(lines) > 0:
		print('it is running')
	else:
		subprocess.call('nohup /usr/local/bin/python /opt/voyager/tools/xc_gdp/readtime.py &', shell=True)
                print('restart ok')
	time.sleep(1)


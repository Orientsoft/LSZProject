#coding:utf-8

import xlrd
import redis

r = redis.Redis(host='127.0.0.1',port=6379)

################################gdp######################

xls_name = 'xc.xls'
obj_excel = xlrd.open_workbook(xls_name)
sheet = obj_excel.sheet_by_name('Sheet1')

xls_rows = sheet.nrows
xls_cols = sheet.ncols

year = range(1,xls_cols,3)
industry = range(1,xls_cols)
city = range(5,xls_rows-1)
data_cols = range(1,xls_cols)
num = 1
alldata = {}
forsort = []
turn_alldata = {}
for y in year:
	for c in city:
		for i in [y,y+1,y+2]:
			item =  sheet.cell_value(1,y) + ',' + sheet.cell_value(c,0) + ',' + sheet.cell_value(3,i)
			alldata[item] = sheet.cell_value(c,i)
print(xls_rows,xls_cols)
print('year:',year)
print('industry:',industry)
print('city:',city)

for key in alldata:
	k = key
	v = alldata[key]
	r.zadd('xctest',k,v)

###########################gdp########################
#####gvy#########grow_value_year###################
xls_name_gvy = 'xc2.xls'
obj_excel_gvy = xlrd.open_workbook(xls_name_gvy)
sheet_gvy = obj_excel_gvy.sheet_by_name('grow_value_year')

xls_rows_gvy = sheet_gvy.nrows
xls_cols_gvy = sheet_gvy.ncols

year_gvy = range(1,xls_cols_gvy)
city_gvy = range(3,xls_rows_gvy-1)

alldata_gvy = {}

for y in year_gvy:
	for c in city_gvy:
		item = sheet_gvy.cell_value(2,y) + ',' + sheet_gvy.cell_value(c,0)
		alldata_gvy[item] = sheet_gvy.cell_value(c,y)

for key in alldata_gvy:
	k = key
	v = alldata_gvy[key]
	r.zadd('xc_gvy',k,v)
##################gvy#############grow_value_year#####################3
##################gry#############grow_rate_year#####################3
xls_name_gry = 'xc2.xls'
obj_excel_gry = xlrd.open_workbook(xls_name_gry)
sheet_gry = obj_excel_gry.sheet_by_name('grow_rate_year')

xls_rows_gry = sheet_gry.nrows
xls_cols_gry = sheet_gry.ncols

testdata = sheet_gry.cell_value(2,1)
year_gry = range(1,xls_cols_gry)
city_gry = range(4,xls_rows_gry-1)
alldata_gry = {}

for y in year_gry:
	for c in city_gry:
		item = sheet_gry.cell_value(2,y) + ',' + sheet_gry.cell_value(c,0) 
		value = sheet_gry.cell_value(c,y) 
		alldata_gry[item] = value
for key in alldata_gry:
	k = key
	v = alldata_gry[key]	
	r.zadd('xc_gry',k,v)

##################gry#############grow_rate_year#####################3
##################13#############grow_quarter#####################
xls_name_gvq1 = 'xc2.xls'
obj_excel_gvq1 = xlrd.open_workbook(xls_name_gvq1)
sheet_gvq1 = obj_excel_gvq1.sheet_by_name('grow_value_quarter')

xls_rows_gvq1 = sheet_gvq1.nrows
xls_cols_gvq1 = sheet_gvq1.ncols

year_gvq1 = range(1,xls_cols_gvq1,4)
quarter_gvq1 = range(1,xls_cols_gvq1,4)
city_gvq1 = range(4,xls_rows_gvq1-1)

alldata_gvq1 = {}

testdata = sheet_gvq1.cell_value(2,1)


for y in year_gvq1:
	for c in city_gvq1:
			item = sheet_gvq1.cell_value(2,y) + ',' + sheet_gvq1.cell_value(c,0) + ',' + sheet_gvq1.cell_value(3,y)
			value = sheet_gvq1.cell_value(c,y)
			alldata_gvq1[item] = value
for key in alldata_gvq1:
	k = key
	v = alldata_gvq1[key]
	r.zadd('xc_gvq1',k,v)










#coding:utf-8

import xlrd
import redis

r = redis.Redis(host='127.0.0.1',port=6379)

################################q1_peasant_cash_in_v######################
def con_cash_q1():
	xls_name = 'con_cash.xls'
	obj_excel = xlrd.open_workbook(xls_name)
	sheet = obj_excel.sheet_by_name('con_cash_q1')

	xls_rows = sheet.nrows
	xls_cols = sheet.ncols
	print(xls_rows,xls_cols)
	
	year = range(1,xls_cols)
	alldata = {}
	for y in year:
		item = sheet.cell_value(1,y) 
		alldata[item] = sheet.cell_value(4,y)
	print(alldata)
	for key in alldata:
		k = key
		v = alldata[key]
		r.zadd('con_cash_q1',k,v)

################################q1_peasant_cash_in_v######################
def con_cash_q2():
        xls_name = 'con_cash.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('con_cash_q2')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('con_cash_q2',k,v)
################################q1_peasant_cash_in_v######################
def con_cash_q3():
        xls_name = 'con_cash.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('con_cash_q3')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('con_cash_q3',k,v)
################################q1_peasant_cash_in_v######################
def con_cash_q4():
        xls_name = 'con_cash.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('con_cash_q4')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('con_cash_q4',k,v)
################################q1_peasant_cash_in_v######################
def con_cash_rq1():
        xls_name = 'con_cash.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('con_cash_rq2')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('con_cash_rq1',k,v)
################################q1_peasant_cash_in_v######################
def con_cash_rq2():
        xls_name = 'con_cash.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('con_cash_rq2')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('con_cash_rq2',k,v)
################################q1_peasant_cash_in_v######################
def con_cash_rq3():
        xls_name = 'con_cash.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('con_cash_rq3')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('con_cash_rq3',k,v)
################################q1_peasant_cash_in_v######################
def con_cash_rq4():
        xls_name = 'con_cash.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('con_cash_rq4')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('con_cash_rq4',k,v)
con_cash_q1()
con_cash_q2()
con_cash_q3()
con_cash_q4()
con_cash_rq1()
con_cash_rq2()
con_cash_rq3()
con_cash_rq4()

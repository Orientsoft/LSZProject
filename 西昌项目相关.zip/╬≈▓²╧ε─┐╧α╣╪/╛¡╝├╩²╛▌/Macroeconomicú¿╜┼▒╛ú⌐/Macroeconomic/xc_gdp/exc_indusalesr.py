#coding:utf-8

import xlrd
import redis

r = redis.Redis(host='127.0.0.1',port=6379)

################################q1_peasant_cash_in_v######################
def indusr_q1():
	xls_name = 'indu_sales_r.xls'
	obj_excel = xlrd.open_workbook(xls_name)
	sheet = obj_excel.sheet_by_name('indusr_q1')

	xls_rows = sheet.nrows
	xls_cols = sheet.ncols
	
	year = range(1,xls_cols)
	alldata = {}
	for y in year:
		item = sheet.cell_value(1,y) 
		alldata[item] = sheet.cell_value(3,y)
	for key in alldata:
		k = key
		v = alldata[key]
		r.zadd('indusr_q1',k,v)

################################q1_peasant_cash_in_v######################
def indusr_q2():
        xls_name = 'indu_sales_r.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('indusr_q2')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
#        print(xls_rows,xls_cols)
        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(2,y)
                alldata[item] = sheet.cell_value(4,y)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('indusr_q2',k,v)
################################q1_peasant_cash_in_v######################
def indusr_q3():
        xls_name = 'indu_sales_r.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('indusr_q3')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(3,y)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('indusr_q3',k,v)
################################q1_peasant_cash_in_v######################
def indusr_q4():
        xls_name = 'indu_sales_r.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('indusr_q4')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(3,y)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('indusr_q4',k,v)
################################q1_peasant_cash_in_v######################
def indusr_m14():
        xls_name = 'indu_sales_r.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('indusr_m14')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(3,y)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('indusr_m14',k,v)
################################q1_peasant_cash_in_v######################
def indusr_m15():
        xls_name = 'indu_sales_r.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('indusr_m15')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(3,y)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('indusr_m15',k,v)
################################q1_peasant_cash_in_v######################
def indusr_m17():
        xls_name = 'indu_sales_r.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('indusr_m17')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(3,y)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('indusr_m17',k,v)
################################q1_peasant_cash_in_v######################
def indusr_m18():
        xls_name = 'indu_sales_r.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('indusr_m18')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(3,y)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('indusr_m18',k,v)
################################q1_peasant_cash_in_v######################
def indusr_m110():
        xls_name = 'indu_sales_r.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('indusr_m110')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(3,y)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('indusr_m110',k,v)
################################q1_peasant_cash_in_v######################
def indusr_m111():
        xls_name = 'indu_sales_r.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('indusr_m111')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(3,y)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('indusr_m111',k,v)

indusr_q1()
indusr_q2()
indusr_q3()
indusr_q4()
indusr_m14()
indusr_m15()
indusr_m17()
indusr_m18()
indusr_m110()
indusr_m111()

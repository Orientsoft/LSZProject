#coding:utf-8

import xlrd
import redis

r = redis.Redis(host='127.0.0.1',port=6379)

################################q1_peasant_cash_in_v######################
def indusv_q1():
	xls_name = 'indu_sales_v.xls'
	obj_excel = xlrd.open_workbook(xls_name)
	sheet = obj_excel.sheet_by_name('indusv_q1')

	xls_rows = sheet.nrows
	xls_cols = sheet.ncols
	print(xls_rows,xls_cols)
	
	year = range(1,xls_cols)
	alldata = {}
	for y in year:
		item = sheet.cell_value(1,y) 
		alldata[item] = sheet.cell_value(4,y)
	print(alldata)
	for key in alldata:
		k = key
		v = alldata[key]
		r.zadd('indusv_q1',k,v)

################################q1_peasant_cash_in_v######################
def indusv_q2():
        xls_name = 'indu_sales_v.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('indusv_q2')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('indusv_q2',k,v)
################################q1_peasant_cash_in_v######################
def indusv_q3():
        xls_name = 'indu_sales_v.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('indusv_q3')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('indusv_q3',k,v)
################################q1_peasant_cash_in_v######################
def indusv_q4():
        xls_name = 'indu_sales_v.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('indusv_q4')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('indusv_q4',k,v)
################################q1_peasant_cash_in_v######################
def indugr_q1():
        xls_name = 'indu_sales_v.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('indugr_q1')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('indugr_q1',k,v)
################################q1_peasant_cash_in_v######################
def indugr_q2():
        xls_name = 'indu_sales_v.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('indugr_q2')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('indugr_q2',k,v)
################################q1_peasant_cash_in_v######################
def indugr_q3():
        xls_name = 'indu_sales_v.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('indugr_q3')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('indugr_q3',k,v)
################################q1_peasant_cash_in_v######################
def indugr_q4():
        xls_name = 'indu_sales_v.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('indugr_q4')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('indugr_q4',k,v)
################################q1_peasant_cash_in_v######################
def indugr_m12():
        xls_name = 'indu_sales_v.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('indugr_m12')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('indugr_m12',k,v)
################################q1_peasant_cash_in_v######################
def indugr_m14():
        xls_name = 'indu_sales_v.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('indugr_m14')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('indugr_m14',k,v)

################################q1_peasant_cash_in_v######################
def indugr_m15():
        xls_name = 'indu_sales_v.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('indugr_m15')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('indugr_m15',k,v)

################################q1_peasant_cash_in_v######################
def indugr_m17():
        xls_name = 'indu_sales_v.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('indugr_m17')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('indugr_m17',k,v)

################################q1_peasant_cash_in_v######################
def indugr_m18():
        xls_name = 'indu_sales_v.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('indugr_m18')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('indugr_m18',k,v)

################################q1_peasant_cash_in_v######################
def indugr_m110():
        xls_name = 'indu_sales_v.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('indugr_m110')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('indugr_m110',k,v)
################################q1_peasant_cash_in_v######################
def indugr_m111():
        xls_name = 'indu_sales_v.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('indugr_m111')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('indugr_m111',k,v)
indusv_q1()
indusv_q2()
indusv_q3()
indusv_q4()
indugr_q1()
indugr_q2()
indugr_q3()
indugr_q4()
indugr_m12()
indugr_m14()
indugr_m15()
indugr_m17()
indugr_m18()
indugr_m110()
indugr_m111()

#coding:utf-8

import xlrd
import redis

r = redis.Redis(host='127.0.0.1',port=6379)

################################lgbe_10-15_quarter1_gv######################

def lgbe_1015_quarter1_gv():
	xls_name = 'lgbe.xls'
	obj_excel = xlrd.open_workbook(xls_name)
	sheet = obj_excel.sheet_by_name('10-15_quarter1_gv')

	xls_rows = sheet.nrows
	xls_cols = sheet.ncols

	year = range(1,xls_cols)
	alldata = {}

	for y in year:
		item = sheet.cell_value(1,y) 
		alldata[item] = sheet.cell_value(5,y)

	for key in alldata:
		k = key
		v = alldata[key]
		r.zadd('lgbe_1015_quarter1_gv',k,v)

################################lgbe_10-15_quarter2_gv######################
def lgbe_1015_quarter2_gv():
	xls_name = 'lgbe.xls'
	obj_excel = xlrd.open_workbook(xls_name)
	sheet = obj_excel.sheet_by_name('10-15_quarter2_gv')
	
	xls_rows = sheet.nrows
	xls_cols = sheet.ncols
	
	year = range(1,xls_cols)
	alldata = {}
	for y in year:
		item = sheet.cell_value(1,y)
		alldata[item] = sheet.cell_value(5,y)
	for key in alldata:
		k = key
		v = alldata[key]
		r.zadd('lgbe_1015_quarter2_gv',k,v)
################################lgbe_10-15_quarter3_gv######################
def lgbe_1015_quarter3_gv():
        xls_name = 'lgbe.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('10-15_quarter3_gv')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols

        year = range(1,xls_cols-1)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(5,y)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('lgbe_1015_quarter3_gv',k,v)
################################lgbe_10-15_quarter4_gv######################
def lgbe_1015_quarter4_gv():
        xls_name = 'lgbe.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('10-15_quarter4_gv')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(5,y)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('lgbe_1015_quarter4_gv',k,v)

################################lgbe_10-15_quarter1_gr######################
def lgbe_1015_quarter1_gr():
        xls_name = 'lgbe.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('10-15_quarter1_gr')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(5,y)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('lgbe_1015_quarter1_gr',k,v)

################################lgbe_10-15_quarter2_gr######################
def lgbe_1015_quarter2_gr():
        xls_name = 'lgbe.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('10-15_quarter2_gr')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(5,y)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('lgbe_1015_quarter2_gr',k,v)
################################lgbe_10-15_quarter3_gr######################
def lgbe_1015_quarter3_gr():
        xls_name = 'lgbe.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('10-15_quarter3_gr')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols

        year = range(1,xls_cols-1)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(5,y)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('lgbe_1015_quarter3_gr',k,v)
################################lgbe_10-15_quarter4_gr######################
def lgbe_1015_quarter4_gr():
        xls_name = 'lgbe.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('10-15_quarter4_gr')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(5,y)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('lgbe_1015_quarter4_gr',k,v)

################################lgbe_10-15_month2_gr######################
def lgbe_1015_month2_gr():
        xls_name = 'lgbe.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('10-15_month2_gr')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(5,y)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('lgbe_1015_month2_gr',k,v)
################################lgbe_10-15_month4_gr######################
def lgbe_1015_month4_gr():
        xls_name = 'lgbe.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('10-15_month4_gr')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(5,y)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('lgbe_1015_month4_gr',k,v)
################################lgbe_10-15_month5_gr######################
def lgbe_1015_month5_gr():
        xls_name = 'lgbe.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('10-15_month5_gr')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(5,y)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('lgbe_1015_month5_gr',k,v)
################################lgbe_10-15_month7_gr######################
def lgbe_1015_month7_gr():
        xls_name = 'lgbe.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('10-15_month7_gr')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(5,y)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('lgbe_1015_month7_gr',k,v)
################################lgbe_10-15_month8_gr######################
def lgbe_1015_month8_gr():
        xls_name = 'lgbe.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('10-15_month8_gr')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(5,y)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('lgbe_1015_month8_gr',k,v)
################################lgbe_10-15_month10_gr######################
def lgbe_1015_month10_gr():
        xls_name = 'lgbe.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('10-15_month10_gr')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(5,y)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('lgbe_1015_month10_gr',k,v)
################################lgbe_10-15_month11_gr######################
def lgbe_1015_month11_gr():
        xls_name = 'lgbe.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('10-15_month11_gr')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(5,y)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('lgbe_1015_month11_gr',k,v)
lgbe_1015_quarter1_gv()
lgbe_1015_quarter2_gv()
lgbe_1015_quarter3_gv()
lgbe_1015_quarter4_gv()
lgbe_1015_quarter1_gr()
lgbe_1015_quarter2_gr()
lgbe_1015_quarter3_gr()
lgbe_1015_quarter4_gr()
lgbe_1015_month2_gr()
lgbe_1015_month4_gr()
lgbe_1015_month5_gr()
lgbe_1015_month7_gr()
lgbe_1015_month8_gr()
lgbe_1015_month10_gr()
lgbe_1015_month11_gr()











#coding:utf-8
import xlrd
import redis

r = redis.Redis(host='127.0.0.1',port=6379)

def indus():
	xls_fix = 'map_fix.xls'
	obj_fix = xlrd.open_workbook(xls_fix)
	sheet_map_fix_v = obj_fix.sheet_by_name('map_fix_v')
	sheet_map_fix_r = obj_fix.sheet_by_name('map_fix_r')

	fix_v_xls_rows = sheet_map_fix_v.nrows
	fix_v_xls_cols = sheet_map_fix_v.ncols
	year_fix_v = range(1,fix_v_xls_cols)
	value_fix_v = range(5,fix_v_xls_rows - 1)
	
	fix_r_xls_rows = sheet_map_fix_r.nrows
        fix_r_xls_cols = sheet_map_fix_r.ncols
        year_fix_r = range(1,fix_r_xls_cols)
        value_fix_r = range(5,fix_r_xls_rows - 1)

#################	

	xls_gdp = 'map_gdp.xls'
	obj_gdp = xlrd.open_workbook(xls_gdp)
        sheet_map_gdp_v = obj_gdp.sheet_by_name('map_gdp_v')
        sheet_map_gdp_r = obj_gdp.sheet_by_name('map_gdp_r')

	gdp_v_xls_rows = sheet_map_gdp_v.nrows
        gdp_v_xls_cols = sheet_map_gdp_v.ncols
        year_gdp_v = range(1,gdp_v_xls_cols)
        value_gdp_v = range(4,gdp_v_xls_rows - 1)

        gdp_r_xls_rows = sheet_map_gdp_r.nrows
        gdp_r_xls_cols = sheet_map_gdp_r.ncols
        year_gdp_r = range(1,gdp_r_xls_cols)
        value_gdp_r = range(4,gdp_r_xls_rows - 1)
###################

	xls_sales = 'map_sales.xls'
        obj_sales = xlrd.open_workbook(xls_sales)
        sheet_map_sales_v = obj_sales.sheet_by_name('map_sales_v')
        sheet_map_sales_r = obj_sales.sheet_by_name('map_sales_r')

        sales_v_xls_rows = sheet_map_sales_v.nrows
        sales_v_xls_cols = sheet_map_sales_v.ncols
        year_sales_v = range(1,sales_v_xls_cols)
        value_sales_v = range(4,sales_v_xls_rows - 1)

        sales_r_xls_rows = sheet_map_sales_r.nrows
        sales_r_xls_cols = sheet_map_sales_r.ncols
        year_sales_r = range(1,sales_r_xls_cols)
        value_sales_r = range(4,sales_r_xls_rows - 1)

	print(year_gdp_v,value_gdp_v)
	print(sheet_map_gdp_v.cell_value(1,1))
	print(sheet_map_gdp_v.cell_value(4,1))

	print(sheet_map_gdp_r.cell_value(1,1))
        print(sheet_map_gdp_r.cell_value(4,1))	

	map_data = []
	fixdata = []
	gdpdata = []
	for y in year_gdp_v:
		for v in value_gdp_v:
#			data_fix.append([sheet_map_fix_v.cell_value(1,y) + ',' + sheet_map_fix_v.cell_value(v,y)])
			map_data.append(['fix',sheet_map_fix_v.cell_value(v,0),sheet_map_fix_v.cell_value(1,y),sheet_map_fix_v.cell_value(v,y),sheet_map_fix_r.cell_value(v,y)])
			map_data.append(['gdp',sheet_map_gdp_v.cell_value(v,0),sheet_map_gdp_v.cell_value(1,y),sheet_map_gdp_v.cell_value(v,y),sheet_map_gdp_r.cell_value(v,y)])
	print(map_data)		

#	for key in alldata:
#		k = key
#		v = alldata[key]
#		r.zadd('xc_map_gvy',k,v)
indus()





#coding:utf-8

import xlrd
import redis

r = redis.Redis(host='127.0.0.1',port=6379)

################################q1_peasant_cash_in_v######################
def q1_peasant_cash_in_v():
	xls_name = 'peasant_cash_in.xls'
	obj_excel = xlrd.open_workbook(xls_name)
	sheet = obj_excel.sheet_by_name('q1_peasant_cash_in_v')

	xls_rows = sheet.nrows
	xls_cols = sheet.ncols
	print(xls_rows,xls_cols)
	
	year = range(1,xls_cols)
	alldata = {}
	for y in year:
		item = sheet.cell_value(1,y) 
		alldata[item] = sheet.cell_value(4,y)

	for key in alldata:
		k = key
		v = alldata[key]
		r.zadd('q1_peasant_cash_in_v',k,v)
################################q2_peasant_cash_in_v######################
def q2_peasant_cash_in_v():
        xls_name = 'peasant_cash_in.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('q2_peasant_cash_in_v')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)

        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('q2_peasant_cash_in_v',k,v)

################################q3_peasant_cash_in_v######################
def q3_peasant_cash_in_v():
        xls_name = 'peasant_cash_in.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('q3_peasant_cash_in_v')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)

        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('q3_peasant_cash_in_v',k,v)
################################q4_peasant_cash_in_v######################
def q4_peasant_cash_in_v():
        xls_name = 'peasant_cash_in.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('q4_peasant_cash_in_v')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)

        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('q4_peasant_cash_in_v',k,v)

################################q1_peasant_cash_in_r######################
def q1_peasant_cash_in_r():
        xls_name = 'peasant_cash_in.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('q1_peasant_cash_in_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)

        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('q1_peasant_cash_in_r',k,v)
################################q2_peasant_cash_in_r######################
def q2_peasant_cash_in_r():
        xls_name = 'peasant_cash_in.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('q2_peasant_cash_in_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)

        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('q2_peasant_cash_in_r',k,v)
################################q3_peasant_cash_in_r######################
def q3_peasant_cash_in_r():
        xls_name = 'peasant_cash_in.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('q3_peasant_cash_in_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)

        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('q3_peasant_cash_in_r',k,v)
################################q4_peasant_cash_in_r######################
def q4_peasant_cash_in_r():
        xls_name = 'peasant_cash_in.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('q4_peasant_cash_in_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)

        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('q4_peasant_cash_in_r',k,v)
q1_peasant_cash_in_v()
q2_peasant_cash_in_v()
q3_peasant_cash_in_v()
q4_peasant_cash_in_v()
q1_peasant_cash_in_r()
q2_peasant_cash_in_r()
q3_peasant_cash_in_r()
q4_peasant_cash_in_r()

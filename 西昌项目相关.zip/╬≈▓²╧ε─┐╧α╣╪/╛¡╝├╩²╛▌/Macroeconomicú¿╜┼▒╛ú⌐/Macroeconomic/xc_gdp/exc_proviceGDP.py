#coding:utf-8

import xlrd
import redis

r = redis.Redis(host='127.0.0.1',port=6379)

################################quarter1_provice_gdp_value######################

def quarter1_provice_gdp_value():
	xls_name = 'proviceGDP.xls'
	obj_excel = xlrd.open_workbook(xls_name)
	sheet = obj_excel.sheet_by_name('quarter1_provice_gdp_value')

	xls_rows = sheet.nrows
	xls_cols = sheet.ncols
	print(xls_rows,xls_cols)
	
	year = range(1,xls_cols)
	alldata = {}
	for y in year:
		item = sheet.cell_value(1,y) 
		alldata[item] = sheet.cell_value(4,y)

	for key in alldata:
		k = key
		v = alldata[key]
		r.zadd('quarter1_provice_gdp_value',k,v)
################################quarter2_provice_gdp_value######################

def quarter2_provice_gdp_value():
        xls_name = 'proviceGDP.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('quarter2_provice_gdp_value')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)

        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('quarter2_provice_gdp_value',k,v)
################################quarter3_provice_gdp_value######################
def quarter3_provice_gdp_value():
        xls_name = 'proviceGDP.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('quarter3_provice_gdp_value')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)

        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('quarter3_provice_gdp_value',k,v)

################################quarter4_provice_gdp_value######################

def quarter4_provice_gdp_value():
        xls_name = 'proviceGDP.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('quarter4_provice_gdp_value')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)

        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('quarter4_provice_gdp_value',k,v)
################################quarter1_provice_gdp_rate######################

def quarter1_provice_gdp_rate():
        xls_name = 'proviceGDP.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('quarter1_provice_gdp_rate')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)

        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('quarter1_provice_gdp_rate',k,v)
################################quarter2_provice_gdp_rate######################

def quarter2_provice_gdp_rate():
        xls_name = 'proviceGDP.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('quarter2_provice_gdp_rate')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)

        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('quarter2_provice_gdp_rate',k,v)

################################quarter3_provice_gdp_rate######################

def quarter3_provice_gdp_rate():
        xls_name = 'proviceGDP.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('quarter3_provice_gdp_rate')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)

        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('quarter3_provice_gdp_rate',k,v)
################################quarter4_provice_gdp_rate######################

def quarter4_provice_gdp_rate():
        xls_name = 'proviceGDP.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('quarter4_provice_gdp_rate')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)

        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('quarter4_provice_gdp_rate',k,v)
quarter1_provice_gdp_value()
quarter2_provice_gdp_value()
quarter3_provice_gdp_value()
quarter4_provice_gdp_value()
quarter1_provice_gdp_rate()
quarter2_provice_gdp_rate()
quarter3_provice_gdp_rate()
quarter4_provice_gdp_rate()


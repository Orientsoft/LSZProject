#coding:utf-8

import xlrd
import redis

r = redis.Redis(host='127.0.0.1',port=6379)

################################q1_provice_pri_eco_value######################
def q1_provice_pri_eco_value():
	xls_name = 'province_private_economy.xls'
	obj_excel = xlrd.open_workbook(xls_name)
	sheet = obj_excel.sheet_by_name('q1_provice_pri_eco_value')

	xls_rows = sheet.nrows
	xls_cols = sheet.ncols
	print(xls_rows,xls_cols)
	
	year = range(1,xls_cols)
	alldata = {}
	for y in year:
		item = sheet.cell_value(1,y) 
		alldata[item] = sheet.cell_value(4,y)

	for key in alldata:
		k = key
		v = alldata[key]
		r.zadd('q1_provice_pri_eco_value',k,v)
################################q2_provice_pri_eco_value######################
def q2_provice_pri_eco_value():
        xls_name = 'province_private_economy.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('q2_provice_pri_eco_value')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)

        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('q2_provice_pri_eco_value',k,v)

################################q3_provice_pri_eco_value######################
def q3_provice_pri_eco_value():
        xls_name = 'province_private_economy.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('q3_provice_pri_eco_value')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)

        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('q3_provice_pri_eco_value',k,v)
################################q4_provice_pri_eco_value######################
def q4_provice_pri_eco_value():
        xls_name = 'province_private_economy.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('q4_provice_pri_eco_value')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)

        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('q4_provice_pri_eco_value',k,v)
################################q1_provice_pri_eco_rate######################
def q1_provice_pri_eco_rate():
        xls_name = 'province_private_economy.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('q1_provice_pri_eco_rate')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)

        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('q1_provice_pri_eco_rate',k,v)

################################q2_provice_pri_eco_rate######################
def q2_provice_pri_eco_rate():
        xls_name = 'province_private_economy.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('q2_provice_pri_eco_rate')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)

        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('q2_provice_pri_eco_rate',k,v)

################################q3_provice_pri_eco_rate######################
def q3_provice_pri_eco_rate():
        xls_name = 'province_private_economy.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('q3_provice_pri_eco_rate')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)

        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('q3_provice_pri_eco_rate',k,v)

################################q4_provice_pri_eco_rate######################
def q4_provice_pri_eco_rate():
        xls_name = 'province_private_economy.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('q4_provice_pri_eco_rate')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)

        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('q4_provice_pri_eco_rate',k,v)
q1_provice_pri_eco_value()
q2_provice_pri_eco_value()
q3_provice_pri_eco_value()
q4_provice_pri_eco_value()
q1_provice_pri_eco_rate()
q2_provice_pri_eco_rate()
q3_provice_pri_eco_rate()
q4_provice_pri_eco_rate()

#coding:utf-8

import xlrd
import redis

r = redis.Redis(host='127.0.0.1',port=6379)

################################q1_peasant_cash_in_v######################
def re_q1_v():
	xls_name = 'real_estate.xls'
	obj_excel = xlrd.open_workbook(xls_name)
	sheet = obj_excel.sheet_by_name('re_q1_v')

	xls_rows = sheet.nrows
	xls_cols = sheet.ncols
	print(xls_rows,xls_cols)
	
	year = range(1,xls_cols)
	alldata = {}
	for y in year:
		item = sheet.cell_value(1,y) 
		alldata[item] = sheet.cell_value(4,y)
	print(alldata)
	for key in alldata:
		k = key
		v = alldata[key]
		r.zadd('re_q1_v',k,v)

################################q1_peasant_cash_in_v######################
def re_q2_v():
        xls_name = 'real_estate.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('re_q2_v')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('re_q2_v',k,v)
################################q1_peasant_cash_in_v######################
def re_q3_v():
        xls_name = 'real_estate.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('re_q3_v')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('re_q3_v',k,v)
################################q1_peasant_cash_in_v######################
def re_q4_v():
        xls_name = 'real_estate.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('re_q4_v')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('re_q4_v',k,v)
################################q1_peasant_cash_in_v######################
def re_q1_r():
        xls_name = 'real_estate.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('re_q1_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('re_q1_r',k,v)
################################q1_peasant_cash_in_v######################
def re_q2_r():
        xls_name = 'real_estate.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('re_q2_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('re_q2_r',k,v)
################################q1_peasant_cash_in_v######################
def re_q3_r():
        xls_name = 'real_estate.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('re_q3_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('re_q3_r',k,v)
################################q1_peasant_cash_in_v######################
def re_q4_r():
        xls_name = 'real_estate.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('re_q4_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('re_q4_r',k,v)
################################q1_peasant_cash_in_v######################
def re_m12_v():
        xls_name = 'real_estate.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('re_m12_v')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('re_m12_v',k,v)
################################q1_peasant_cash_in_v######################
def re_m14_v():
        xls_name = 'real_estate.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('re_m14_v')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('re_m14_v',k,v)
################################q1_peasant_cash_in_v######################
def re_m15_v():
        xls_name = 'real_estate.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('re_m15_v')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('re_m15_v',k,v)

################################q1_peasant_cash_in_v######################
def re_m17_v():
        xls_name = 'real_estate.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('re_m17_v')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('re_m17_v',k,v)

################################q1_peasant_cash_in_v######################
def re_m18_v():
        xls_name = 'real_estate.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('re_m18_v')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('re_m18_v',k,v)

################################q1_peasant_cash_in_v######################
def re_m110_v():
        xls_name = 'real_estate.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('re_m110_v')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('re_m110_v',k,v)

################################q1_peasant_cash_in_v######################
def re_m111_v():
        xls_name = 'real_estate.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('re_m111_v')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('re_m111_v',k,v)
################################q1_peasant_cash_in_v######################
def re_m12_r():
        xls_name = 'real_estate.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('re_m12_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('re_m12_r',k,v)

################################q1_peasant_cash_in_v######################
def re_m14_r():
        xls_name = 'real_estate.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('re_m14_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('re_m14_r',k,v)
################################q1_peasant_cash_in_v######################
def re_m15_r():
        xls_name = 'real_estate.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('re_m15_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('re_m15_r',k,v)
################################q1_peasant_cash_in_v######################
def re_m17_r():
        xls_name = 'real_estate.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('re_m17_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('re_m17_r',k,v)
################################q1_peasant_cash_in_v######################
def re_m18_r():
        xls_name = 'real_estate.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('re_m18_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('re_m18_r',k,v)
################################q1_peasant_cash_in_v######################
def re_m110_r():
        xls_name = 'real_estate.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('re_m110_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('re_m110_r',k,v)
################################q1_peasant_cash_in_v######################
def re_m111_r():
        xls_name = 'real_estate.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('re_m111_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('re_m111_r',k,v)
re_q1_v()
re_q2_v()
re_q3_v()
re_q4_v()
re_q4_v()
re_q1_r()
re_q2_r()
re_q3_r()
re_q4_r()
re_m12_v()
re_m14_v()
re_m15_v()
re_m17_v()
re_m18_v()
re_m110_v()
re_m111_v()
re_m12_r()
re_m14_r()
re_m15_r()
re_m17_r()
re_m18_r()
re_m110_r()
re_m111_r()

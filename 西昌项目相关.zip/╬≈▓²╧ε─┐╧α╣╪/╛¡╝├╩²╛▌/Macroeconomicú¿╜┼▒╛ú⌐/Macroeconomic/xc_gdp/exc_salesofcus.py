#coding:utf-8

import xlrd
import redis

r = redis.Redis(host='127.0.0.1',port=6379)

################################q1_peasant_cash_in_v######################
def sales_q1_v():
	xls_name = 'salesofcus.xls'
	obj_excel = xlrd.open_workbook(xls_name)
	sheet = obj_excel.sheet_by_name('sales_q1_v')

	xls_rows = sheet.nrows
	xls_cols = sheet.ncols
	print(xls_rows,xls_cols)
	
	year = range(1,xls_cols)
	alldata = {}
	for y in year:
		item = sheet.cell_value(1,y) 
		alldata[item] = sheet.cell_value(4,y)
	print(alldata)
	for key in alldata:
		k = key
		v = alldata[key]
		r.zadd('sales_q1_v',k,v)

################################q1_peasant_cash_in_v######################
def sales_q2_v():
        xls_name = 'salesofcus.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sales_q2_v')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sales_q2_v',k,v)
################################q1_peasant_cash_in_v######################
def sales_q3_v():
        xls_name = 'salesofcus.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sales_q3_v')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sales_q3_v',k,v)
################################q1_peasant_cash_in_v######################
def sales_q4_v():
        xls_name = 'salesofcus.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sales_q4_v')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sales_q4_v',k,v)
################################q1_peasant_cash_in_v######################
def sales_q1_r():
        xls_name = 'salesofcus.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sales_q1_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sales_q1_r',k,v)
################################q1_peasant_cash_in_v######################
def sales_q2_r():
        xls_name = 'salesofcus.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sales_q2_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sales_q2_r',k,v)
################################q1_peasant_cash_in_v######################
def sales_q3_r():
        xls_name = 'salesofcus.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sales_q3_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sales_q3_r',k,v)
################################q1_peasant_cash_in_v######################
def sales_q4_r():
        xls_name = 'salesofcus.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sales_q4_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sales_q4_r',k,v)
################################q1_peasant_cash_in_v######################
def sales_m14_v():
        xls_name = 'salesofcus.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sales_m14_v')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sales_m14_v',k,v)
################################q1_peasant_cash_in_v######################
def sales_m15_v():
        xls_name = 'salesofcus.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sales_m15_v')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sales_m15_v',k,v)

################################q1_peasant_cash_in_v######################
def sales_m17_v():
        xls_name = 'salesofcus.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sales_m17_v')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sales_m17_v',k,v)

################################q1_peasant_cash_in_v######################
def sales_m18_v():
        xls_name = 'salesofcus.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sales_m18_v')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sales_m18_v',k,v)

################################q1_peasant_cash_in_v######################
def sales_m110_v():
        xls_name = 'salesofcus.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sales_m110_v')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sales_m110_v',k,v)

################################q1_peasant_cash_in_v######################
def sales_m111_v():
        xls_name = 'salesofcus.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sales_m111_v')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sales_m111_v',k,v)
################################q1_peasant_cash_in_v######################
def sales_m14_r():
        xls_name = 'salesofcus.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sales_m14_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sales_m14_r',k,v)
################################q1_peasant_cash_in_v######################
def sales_m15_r():
        xls_name = 'salesofcus.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sales_m15_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sales_m15_r',k,v)
################################q1_peasant_cash_in_v######################
def sales_m17_r():
        xls_name = 'salesofcus.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sales_m17_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sales_m17_r',k,v)
################################q1_peasant_cash_in_v######################
def sales_m18_r():
        xls_name = 'salesofcus.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sales_m18_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sales_m18_r',k,v)
################################q1_peasant_cash_in_v######################
def sales_m110_r():
        xls_name = 'salesofcus.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sales_m110_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sales_m110_r',k,v)
################################q1_peasant_cash_in_v######################
def sales_m111_r():
        xls_name = 'salesofcus.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sales_m111_r')

        xls_rows = sheet.nrows
        xls_cols = sheet.ncols
        print(xls_rows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sales_m111_r',k,v)
sales_q1_v()
sales_q2_v()
sales_q3_v()
sales_q4_v()
sales_q4_v()
sales_q1_r()
sales_q2_r()
sales_q3_r()
sales_q4_r()
sales_m14_v()
sales_m15_v()
sales_m17_v()
sales_m18_v()
sales_m110_v()
sales_m111_v()
sales_m14_r()
sales_m15_r()
sales_m17_r()
sales_m18_r()
sales_m110_r()
sales_m111_r()

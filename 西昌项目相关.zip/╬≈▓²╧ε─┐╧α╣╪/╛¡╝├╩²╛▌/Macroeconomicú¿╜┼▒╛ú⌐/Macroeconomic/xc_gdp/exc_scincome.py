#coding:utf-8

import xlrd
import redis

r = redis.Redis(host='127.0.0.1',port=6379)

################################q1_peasant_cash_in######################
def sc_in_q1():
	xls_name = 'sc_income.xls'
	obj_excel = xlrd.open_workbook(xls_name)
	sheet = obj_excel.sheet_by_name('sc_in_q1')

	xlsows = sheet.nrows
	xls_cols = sheet.ncols
	print(xlsows,xls_cols)
	
	year = range(1,xls_cols)
	alldata = {}
	for y in year:
		item = sheet.cell_value(1,y) 
		alldata[item] = sheet.cell_value(4,y)
	print(alldata)
	for key in alldata:
		k = key
		v = alldata[key]
		r.zadd('sc_in_q1',k,v)

################################q1_peasant_cash_in######################
def sc_in_q2():
        xls_name = 'sc_income.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sc_in_q2')

        xlsows = sheet.nrows
        xls_cols = sheet.ncols
        print(xlsows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sc_in_q2',k,v)
################################q1_peasant_cash_in######################
def sc_in_q3():
        xls_name = 'sc_income.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sc_in_q3')

        xlsows = sheet.nrows
        xls_cols = sheet.ncols
        print(xlsows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sc_in_q3',k,v)
################################q1_peasant_cash_in######################
def sc_in_q4():
        xls_name = 'sc_income.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sc_in_q4')

        xlsows = sheet.nrows
        xls_cols = sheet.ncols
        print(xlsows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sc_in_q4',k,v)
################################q1_peasant_cash_in######################
def sc_inr_q1():
        xls_name = 'sc_income.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sc_inr_q1')

        xlsows = sheet.nrows
        xls_cols = sheet.ncols
        print(xlsows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sc_inr_q1',k,v)
################################q1_peasant_cash_in######################
def sc_inr_q2():
        xls_name = 'sc_income.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sc_inr_q2')

        xlsows = sheet.nrows
        xls_cols = sheet.ncols
        print(xlsows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sc_inr_q2',k,v)
################################q1_peasant_cash_in######################
def sc_inr_q3():
        xls_name = 'sc_income.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sc_inr_q3')

        xlsows = sheet.nrows
        xls_cols = sheet.ncols
        print(xlsows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sc_inr_q3',k,v)
################################q1_peasant_cash_in######################
def sc_inr_q4():
        xls_name = 'sc_income.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sc_inr_q4')

        xlsows = sheet.nrows
        xls_cols = sheet.ncols
        print(xlsows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sc_inr_q4',k,v)
################################q1_peasant_cash_in######################
def sc_in_m14():
        xls_name = 'sc_income.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sc_in_m14')

        xlsows = sheet.nrows
        xls_cols = sheet.ncols
        print(xlsows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sc_in_m14',k,v)

################################q1_peasant_cash_in######################
def sc_in_m12():
        xls_name = 'sc_income.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sc_in_m12')

        xlsows = sheet.nrows
        xls_cols = sheet.ncols
        print(xlsows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sc_in_m12',k,v)
################################q1_peasant_cash_in######################
def sc_in_m15():
        xls_name = 'sc_income.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sc_in_m15')

        xlsows = sheet.nrows
        xls_cols = sheet.ncols
        print(xlsows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sc_in_m15',k,v)

################################q1_peasant_cash_in######################
def sc_in_m17():
        xls_name = 'sc_income.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sc_in_m17')

        xlsows = sheet.nrows
        xls_cols = sheet.ncols
        print(xlsows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sc_in_m17',k,v)

################################q1_peasant_cash_in######################
def sc_in_m18():
        xls_name = 'sc_income.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sc_in_m18')

        xlsows = sheet.nrows
        xls_cols = sheet.ncols
        print(xlsows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sc_in_m18',k,v)

################################q1_peasant_cash_in######################
def sc_in_m110():
        xls_name = 'sc_income.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sc_in_m110')

        xlsows = sheet.nrows
        xls_cols = sheet.ncols
        print(xlsows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sc_in_m110',k,v)

################################q1_peasant_cash_in######################
def sc_in_m111():
        xls_name = 'sc_income.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sc_in_m111')

        xlsows = sheet.nrows
        xls_cols = sheet.ncols
        print(xlsows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sc_in_m111',k,v)
################################q1_peasant_cash_in######################
def sc_inr_m14():
        xls_name = 'sc_income.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sc_inr_m14')

        xlsows = sheet.nrows
        xls_cols = sheet.ncols
        print(xlsows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sc_inr_m14',k,v)

################################q1_peasant_cash_in######################
def sc_inr_m12():
        xls_name = 'sc_income.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sc_inr_m12')

        xlsows = sheet.nrows
        xls_cols = sheet.ncols
        print(xlsows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sc_inr_m12',k,v)
################################q1_peasant_cash_in######################
def sc_inr_m15():
        xls_name = 'sc_income.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sc_inr_m15')

        xlsows = sheet.nrows
        xls_cols = sheet.ncols
        print(xlsows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sc_inr_m15',k,v)
################################q1_peasant_cash_in######################
def sc_inr_m17():
        xls_name = 'sc_income.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sc_inr_m17')

        xlsows = sheet.nrows
        xls_cols = sheet.ncols
        print(xlsows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sc_inr_m17',k,v)
################################q1_peasant_cash_in######################
def sc_inr_m18():
        xls_name = 'sc_income.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sc_inr_m18')

        xlsows = sheet.nrows
        xls_cols = sheet.ncols
        print(xlsows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sc_inr_m18',k,v)
################################q1_peasant_cash_in######################
def sc_inr_m110():
        xls_name = 'sc_income.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sc_inr_m110')

        xlsows = sheet.nrows
        xls_cols = sheet.ncols
        print(xlsows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sc_inr_m110',k,v)
################################q1_peasant_cash_in######################
def sc_inr_m111():
        xls_name = 'sc_income.xls'
        obj_excel = xlrd.open_workbook(xls_name)
        sheet = obj_excel.sheet_by_name('sc_inr_m111')

        xlsows = sheet.nrows
        xls_cols = sheet.ncols
        print(xlsows,xls_cols)

        year = range(1,xls_cols)
        alldata = {}
        for y in year:
                item = sheet.cell_value(1,y)
                alldata[item] = sheet.cell_value(4,y)
        print(alldata)
        for key in alldata:
                k = key
                v = alldata[key]
                r.zadd('sc_inr_m111',k,v)
sc_in_q1()
sc_in_q2()
sc_in_q3()
sc_in_q4()
sc_in_q4()
sc_in_m12()
sc_in_m14()
sc_in_m15()
sc_in_m17()
sc_in_m18()
sc_in_m110()
sc_in_m111()

sc_inr_q1()
sc_inr_q2()
sc_inr_q3()
sc_inr_q4()
sc_inr_q4()
sc_inr_m12()
sc_inr_m14()
sc_inr_m15()
sc_inr_m17()
sc_inr_m18()
sc_inr_m110()
sc_inr_m111()

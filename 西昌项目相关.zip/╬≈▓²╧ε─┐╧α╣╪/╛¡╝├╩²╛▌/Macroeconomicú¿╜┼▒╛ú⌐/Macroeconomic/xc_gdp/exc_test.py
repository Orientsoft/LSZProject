#coding:utf-8

import xlrd
import redis

r = redis.Redis(host='127.0.0.1',port=6379)

################################gdp######################

xls_name = 'indu.xls'
obj_excel = xlrd.open_workbook(xls_name)
sheet = obj_excel.sheet_by_name('test')

xls_rows = sheet.nrows
xls_cols = sheet.ncols

year = range(1,xls_cols)
month = range(1,xls_cols)
city = range(4,xls_rows-1)
alldata = {}
for y in year:
	for c in city:
#		for i in [y,y+1,y+2]:
		item =  sheet.cell_value(2,y) + ',' + sheet.cell_value(3,y) + ',' + sheet.cell_value(c,0)
		alldata[item] = sheet.cell_value(c,y)
#print(xls_rows,xls_cols)
#print('year:',year)
#print('industry:',industry)
#print('city:',city)
#
for key in alldata:
	k = key
	v = alldata[key]
	r.zadd('indu_test',k,v)
print(year)
print(month)
print(city)
print(sheet.cell_value(2,2))
print(sheet.cell_value(3,2))










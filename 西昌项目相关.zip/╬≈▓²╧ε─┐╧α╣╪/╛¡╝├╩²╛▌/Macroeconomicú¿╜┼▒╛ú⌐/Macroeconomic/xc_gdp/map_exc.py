#coding:utf-8

import xlrd
import redis

r = redis.Redis(host='127.0.0.1',port=6379)

################################gdp######################

xls_name = 'map_gdp.xls'
obj_excel = xlrd.open_workbook(xls_name)
sheet = obj_excel.sheet_by_name('map_gdp_v')

xls_rows = sheet.nrows
xls_cols = sheet.ncols

year = range(1,xls_cols,3)
industry = range(1,xls_cols)
city = range(5,xls_rows-1)
data_cols = range(1,xls_cols)
num = 1
alldata = {}
forsort = []
turn_alldata = {}
for y in year:
	for c in city:
		for i in [y,y+1,y+2]:
			item =  sheet.cell_value(1,y) + ',' + sheet.cell_value(c,0) + ',' + sheet.cell_value(3,i)
			alldata[item] = sheet.cell_value(c,i)

for key in alldata:
	k = key
	v = alldata[key]
	r.zadd('xctest',k,v)







#!/bin/bash
python /opt/voyager/apps/Macroeconomic/xc_gdp/exc_concash.py                 
python /opt/voyager/apps/Macroeconomic/xc_gdp/exc.py                         
python /opt/voyager/apps/Macroeconomic/xc_gdp/exc.py                         
python /opt/voyager/apps/Macroeconomic/xc_gdp/exc_lgbe.py                    
python /opt/voyager/apps/Macroeconomic/xc_gdp/exc_lgbr.py                    
python /opt/voyager/apps/Macroeconomic/xc_gdp/exc_proviceGDP.py              
python /opt/voyager/apps/Macroeconomic/xc_gdp/exc_indusalesr.py              
python /opt/voyager/apps/Macroeconomic/xc_gdp/exc_indusalesv.py              
python /opt/voyager/apps/Macroeconomic/xc_gdp/exc_induaddv.py                
python /opt/voyager/apps/Macroeconomic/xc_gdp/exc_scincome.py                
python /opt/voyager/apps/Macroeconomic/xc_gdp/exc_scout.py                   
python /opt/voyager/apps/Macroeconomic/xc_gdp/exc_realestate.py              
python /opt/voyager/apps/Macroeconomic/xc_gdp/exc_fixedassets.py             
python /opt/voyager/apps/Macroeconomic/xc_gdp/exc_peasant_in.py              
python /opt/voyager/apps/Macroeconomic/xc_gdp/exc_salesofcus.py              
python /opt/voyager/apps/Macroeconomic/xc_gdp/exc_province_private_economy.py


#!/bin/bash
nohup python /opt/voyager/apps/Macroeconomic/xc_www/portal/xc_www.py &

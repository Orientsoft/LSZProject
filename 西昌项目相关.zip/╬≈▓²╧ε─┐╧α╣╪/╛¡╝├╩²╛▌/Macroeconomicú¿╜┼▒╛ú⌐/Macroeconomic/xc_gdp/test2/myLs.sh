#!/bin/bash
ls /opt/voyager/tools/xc_gdp/test2
echo 'total file: '
ls -l /opt/voyager/tools/xc_gdp/test2|wc -l


#!/bin/bash
nohup python /opt/voyager/apps/Macroeconomic/xc_gdp/UpdateDir.py &           


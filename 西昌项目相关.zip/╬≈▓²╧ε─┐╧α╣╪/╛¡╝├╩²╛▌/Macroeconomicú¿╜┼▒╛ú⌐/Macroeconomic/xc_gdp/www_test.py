#coding:utf-8

import xlrd
import redis

r = redis.Redis(host='127.0.0.1',port=6379)

################################q1_peasant_cash_in_v######################
def www_test():
	xls_name = 'indu_sales_r.xls'
	obj_excel = xlrd.open_workbook(xls_name)
	sheet = obj_excel.sheet_by_name('indusr_q4')

	xls_rows = sheet.nrows
	xls_cols = sheet.ncols
	print(xls_rows,xls_cols)
	
	year = range(1,xls_cols)
	local = range(3,xls_rows)
	print(year,local)
	print(sheet.cell_value(3,1))
	alldata = {}
	for y in year:
		for l in local:
			item = sheet.cell_value(1,y) + sheet.cell_value(l,0) 
			alldata[item] = sheet.cell_value(l,y)
	for key in alldata:
		k = key
		v = alldata[key]
		r.zadd('www_test',k,v)

www_test()

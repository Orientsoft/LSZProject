#coding:utf-8

import xlrd
import redis

r = redis.Redis(host='127.0.0.1',port=6379)

xls_name = 'xc.xls'
obj_excel = xlrd.open_workbook(xls_name)
sheet = obj_excel.sheet_by_name('Sheet1')

xls_rows = sheet.nrows
xls_cols = sheet.ncols

year = range(1,xls_cols,3)
industry = range(1,xls_cols)
city = range(5,xls_rows-1)
data_cols = range(1,xls_cols)
num = 1

alldata = {}
#xc_2014_1 = []
#xc_2014_2 = []
#xc_2014_3 = []
#xc_2013_1 = []
#xc_2013_2 = []
#xc_2013_3 = []
#xc_year_d = {}

for y in year:
	for c in city:
		for i in [y,y+1,y+2]:
			item =  sheet.cell_value(1,y) + ',' + sheet.cell_value(c,0) + ',' + sheet.cell_value(3,i)
			alldata[item] = sheet.cell_value(c,i)
#			item =  sheet.cell_value(1,y) + ',' + sheet.cell_value(c,0) + ',' + sheet.cell_value(3,i) + ',' + str(sheet.cell_value(c,1))
#			alldata.append(item)
print(xls_rows,xls_cols)
print('year:',year)
print('industry:',industry)
print('city:',city)
#print(alldata)
#r.zadd('one','f',1)

for key in alldata:
	k = key
	v = alldata[key]
	r.zadd('xctest',k,v)
#for item in alldata:
#	r.sadd('xctest',item)

#	r.zadd('xc_gdp',k,v)

#for k in alldata:
#	if k.split(',')[0] == u'2014年' and k.split(',')[2] == u'第一产业':
#		xc_2014_1.append(alldata[k])
#	if k.split(',')[0] == u'2014年' and k.split(',')[2] == u'第二产业':
#		xc_2014_2.append(alldata[k])
#	if k.split(',')[0] == u'2014年' and k.split(',')[2] == u'第三产业':
#		xc_2014_3.append(alldata[k])
#
#	if k.split(',')[0] == u'2013年' and k.split(',')[2] == u'第一产业':
#		xc_2013_1.append(alldata[k])
#	if k.split(',')[0] == u'2013年' and k.split(',')[2] == u'第二产业':
#		xc_2013_2.append(alldata[k])
#	if k.split(',')[0] == u'2013年' and k.split(',')[2] == u'第三产业':
#		xc_2013_3.append(alldata[k])
#	
#	
#xc_year_d['2014年第一产业'] = sum(xc_2014_1)/2
#xc_year_d['2014年第二产业'] = sum(xc_2014_2)/2
#xc_year_d['2014年第三产业'] = sum(xc_2014_3)/2
#
#xc_year_d['2013年第一产业'] = sum(xc_2013_1)/2
#xc_year_d['2013年第二产业'] = sum(xc_2013_2)/2
#xc_year_d['2013年第三产业'] = sum(xc_2013_3)/2
		 

#for key in xc_year_d:
#	k = key
#	v = xc_year_d[k]
#	r.zadd('xctest2',k,v)
